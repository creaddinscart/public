package studio.shitpub.videorenderer.render;

import java.awt.image.BufferedImage;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_10799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;

/**
 * Version shim for Minecraft 1.21.11 (Yarn, post render-refactor API).
 *
 * Owns the NativeImageBackedTexture lifecycle and the DrawContext.drawTexture
 * call so the shared player code stays version independent. Only this file
 * changes between targets.
 *
 * Built by CREADDINSCART STUDIO.
 */
public final class VideoTextureRenderer {

    private final class_310 client;
    private final int width;
    private final int height;
    private final class_2960 id;
    private final class_1011 image;
    private final class_1043 texture;

    public VideoTextureRenderer(class_310 client, int width, int height) {
        this.client = client;
        this.width = Math.max(1, width);
        this.height = Math.max(1, height);
        this.id = class_2960.method_60655("videorenderer", "video_frame_" + System.nanoTime());
        this.image = new class_1011(this.width, this.height, false);
        this.texture = new class_1043(() -> "videorenderer video frame", this.image);
        client.method_1531().method_4616(this.id, this.texture);
    }

    public void update(BufferedImage frame) {
        if (frame == null) return;
        int fw = Math.min(width, frame.getWidth());
        int fh = Math.min(height, frame.getHeight());
        for (int y = 0; y < fh; y++) {
            for (int x = 0; x < fw; x++) {
                image.method_61941(x, y, frame.getRGB(x, y));
            }
        }
        texture.method_4524();
    }

    public void draw(class_332 context, int x, int y, int w, int h) {
        context.method_25290(class_10799.field_56883, id, x, y, 0.0F, 0.0F, w, h, width, height);
    }

    public void release() {
        texture.close();
        image.close();
    }
}
