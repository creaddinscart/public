package studio.shitpub.videorenderer;

import studio.shitpub.videorenderer.render.VideoTextureRenderer;

import java.awt.image.BufferedImage;
import java.util.Locale;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * The in-game video player screen.
 *
 * Flow: enter a world -> open this screen (keybind, /video, or the pause-menu
 * button) -> paste a video link -> the link is auto-parsed over the network,
 * decoded with the bundled pure-Java decoder, and rendered frame by frame.
 *
 * Created by Btoom KtCher through CREADDINSCART STUDIO.
 * Built by CREADDINSCART STUDIO - https://www.shit.pub/studio/
 */
public class VideoScreen extends class_437 {

    private final String pendingUrl;

    private class_342 urlField;

    private volatile boolean loading = false;
    private volatile String status = "Paste a video link and press Play.";

    private volatile VideoDecoder pendingDecoder;

    private VideoDecoder decoder;
    private VideoTextureRenderer renderer;

    private long nextFrameNanos = 0L;

    public VideoScreen(String initialUrl) {
        super(class_2561.method_43470("Video Renderer"));
        this.pendingUrl = initialUrl;
    }

    @Override
    protected void method_25426() {
        int cx = this.field_22789 / 2;
        int cy = this.field_22790 / 2;

        this.urlField = new class_342(this.field_22793, cx - 160, cy - 90, 320, 20,
                class_2561.method_43470("Video URL"));
        this.urlField.method_47404(class_2561.method_43470("https://example.com/clip.mp4"));
        if (this.pendingUrl != null) {
            this.urlField.method_1852(this.pendingUrl);
        }
        this.method_37063(this.urlField);

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Play"), button -> start(this.urlField.method_1882()))
                .method_46434(cx - 160, cy - 66, 80, 20).method_46431());

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Stop"), button -> stop())
                .method_46434(cx - 76, cy - 66, 60, 20).method_46431());

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Done"), button -> this.method_25419())
                .method_46434(cx + 100, cy - 66, 60, 20).method_46431());

        this.method_48265(this.urlField);
    }

    private void start(String url) {
        if (loading) return;
        stop();
        loading = true;
        status = "Resolving link over the network...";
        Thread worker = new Thread(() -> {
            VideoLinkResolver.Resolved resolved = VideoLinkResolver.resolve(url);
            if (resolved.kind() == VideoLinkResolver.Kind.DIRECT_VIDEO) {
                try {
                    this.pendingDecoder = VideoDecoder.open(resolved.file());
                } catch (Throwable t) {
                    this.status = "Could not decode: " + t.getMessage();
                }
            } else {
                this.status = resolved.message();
            }
            this.loading = false;
        }, "VideoRenderer-Load");
        worker.setDaemon(true);
        worker.start();
    }

    private void stop() {
        if (this.renderer != null) {
            this.renderer.release();
            this.renderer = null;
        }
        if (this.decoder != null) {
            this.decoder.close();
            this.decoder = null;
        }
        if (this.pendingDecoder != null) {
            this.pendingDecoder.close();
            this.pendingDecoder = null;
        }
        this.nextFrameNanos = 0L;
    }

    @Override
    public void method_25393() {
        super.method_25393();

        // Pick up an asynchronously resolved decoder on the client thread.
        VideoDecoder ready = this.pendingDecoder;
        if (ready != null) {
            this.decoder = ready;
            this.pendingDecoder = null;
            this.renderer = new VideoTextureRenderer(class_310.method_1551(), ready.width(), ready.height());
            this.status = "Playing " + ready.width() + "x" + ready.height()
                    + " @ " + String.format(Locale.ROOT, "%.1f", ready.frameRate()) + " fps";
            this.nextFrameNanos = System.nanoTime();
        }

        // Advance one frame when its display time elapses.
        if (this.decoder != null && this.renderer != null && !this.decoder.finished()) {
            long now = System.nanoTime();
            if (now >= this.nextFrameNanos) {
                BufferedImage frame = this.decoder.nextFrame();
                if (frame != null) {
                    this.renderer.update(frame);
                    double fps = Math.max(1.0, this.decoder.frameRate());
                    this.nextFrameNanos = now + (long) (1_000_000_000L / fps);
                } else {
                    this.status = "End of stream.";
                }
            }
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);

        int cx = this.field_22789 / 2;
        int top = this.field_22790 / 2 - 50;

        if (this.renderer != null && this.decoder != null) {
            int maxW = 320, maxH = 180;
            double ar = (double) this.decoder.width() / (double) Math.max(1, this.decoder.height());
            int drawW = maxW;
            int drawH = (int) (drawW / ar);
            if (drawH > maxH) {
                drawH = maxH;
                drawW = (int) (drawH * ar);
            }
            int x = cx - drawW / 2;
            context.method_25294(x - 2, top - 2, x + drawW + 2, top + drawH + 2, 0xFF101018);
            this.renderer.draw(context, x, top, drawW, drawH);
        }

        context.method_25300(this.field_22793,
                "Video Renderer - Btoom KtCher / CREADDINSCART STUDIO",
                cx, this.field_22790 - 28, 0xFFB8C0E0);
        context.method_25300(this.field_22793, this.status, cx, top + 190, 0xFFFFFFFF);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public void method_25419() {
        stop();
        super.method_25419();
    }
}
