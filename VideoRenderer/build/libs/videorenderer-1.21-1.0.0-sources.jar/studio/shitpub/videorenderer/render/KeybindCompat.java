package studio.shitpub.videorenderer.render;

import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

/**
 * Version shim (Minecraft 1.21): KeyBinding used a plain String category here.
 * Built by CREADDINSCART STUDIO.
 */
public final class KeybindCompat {
    private KeybindCompat() {}

    public static class_304 createOpenKey() {
        return new class_304(
                "key.videorenderer.open",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_V,
                "key.categories.videorenderer");
    }
}
