package studio.creaddinscart.imagepreviewer.chat;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import studio.creaddinscart.imagepreviewer.ImagePreviewerMod;

import java.awt.image.BufferedImage;
import net.minecraft.class_124;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_310;
import net.minecraft.class_5250;

/**
 * Handles the "click to preview" interaction pipeline for an image URL in chat.
 *
 * @author GMA
 * @since 1.0.0
 */
public class ClickToRenderAction {

    private static final Logger LOGGER = LoggerFactory.getLogger(ImagePreviewerMod.MOD_ID + "/ClickAction");

    /**
     * Creates a {@link class_2558} that triggers image preview when activated.
     */
    public static class_2558 createPreviewClick(String imageUrl) {
        String command = "/imagepreviewer_preview " + imageUrl;
        return new class_2558(class_2558.class_2559.field_11750, command);
    }

    /**
     * Creates a {@link class_2568} showing a "click to preview" tooltip.
     * On 1.21.4 {@link class_2568} is non-generic; {@code SHOW_TEXT} carries a {@link class_2561}.
     */
    public static class_2568 createPreviewHover(String imageUrl) {
        class_5250 tooltip = class_2561.method_43473()
                .method_10852(class_2561.method_43471("imagepreviewer.tooltip.click_to_preview")
                        .method_27695(class_124.field_1060, class_124.field_1067))
                .method_10852(class_2561.method_43470("\n"))
                .method_10852(class_2561.method_43470(truncateUrl(imageUrl, 60)).method_27692(class_124.field_1080));
        return new class_2568(class_2568.class_5247.field_24342, tooltip);
    }

    /**
     * Executes the image preview flow: cache check -> async fetch -> render.
     */
    public static void execute(String imageUrl) {
        class_310 client = class_310.method_1551();
        if (client == null) {
            LOGGER.error("MinecraftClient is null — cannot execute preview.");
            return;
        }

        if (!ImagePreviewerMod.config.isEnabled()) {
            sendChatMessage(client, class_2561.method_43471("imagepreviewer.error.disabled").method_27692(class_124.field_1054));
            return;
        }

        if (imageUrl == null || imageUrl.isBlank()) {
            sendChatMessage(client, class_2561.method_43471("imagepreviewer.error.invalid_url").method_27692(class_124.field_1061));
            return;
        }

        LOGGER.info("Preview requested for: {}", imageUrl);

        BufferedImage cached = ImagePreviewerMod.imageFetcher.getCached(imageUrl);
        if (cached != null) {
            client.execute(() -> ImagePreviewerMod.imageRenderer.displayImage(cached));
            return;
        }

        sendChatMessage(client, class_2561.method_43471("imagepreviewer.status.loading").method_27692(class_124.field_1075));

        ImagePreviewerMod.imageFetcher.fetchAsync(imageUrl, image -> {
            if (image != null) {
                client.execute(() -> ImagePreviewerMod.imageRenderer.displayImage(image));
            } else {
                client.execute(() -> sendChatMessage(client,
                        class_2561.method_43471("imagepreviewer.error.network").method_27692(class_124.field_1061)));
            }
        });
    }

    /**
     * Builds a styled, clickable chat component for an image URL.
     */
    public static class_5250 buildClickableText(String url) {
        return class_2561.method_43470(url).method_27694(style -> style
                .method_10977(class_124.field_1075)
                .method_30938(true)
                .method_10958(createPreviewClick(url))
                .method_10949(createPreviewHover(url)));
    }

    private static void sendChatMessage(class_310 client, class_2561 message) {
        if (client.field_1705 != null) {
            client.field_1705.method_1743().method_1812(message);
        }
    }

    private static String truncateUrl(String url, int maxChars) {
        if (url == null) return "";
        if (url.length() <= maxChars) return url;
        return url.substring(0, maxChars - 3) + "...";
    }
}
